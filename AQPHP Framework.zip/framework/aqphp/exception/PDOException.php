<?php
/* +----------------------------------------------------------------
 * | Software: [AQPHP framework]
 * |  WebSite: www.aqphp.com
 * |----------------------------------------------------------------
 * | Author: 赵 港 <Vincent> < admin@gzibm.com | 847623251@qq.com >
 * | WeChat: GZIDCW
 * | Copyright (C) 2015-2020, www.aqphp.com All Rights Reserved.
 * +----------------------------------------------------------------*/

namespace aqphp\exception;

use Aqphp\Exception;

/**
 * Created by PhpStorm.
 * User: Vincent
 * Date: 12/23/2017
 * Time: 11:03 PM
 */

class PDOException extends Exception
{

}