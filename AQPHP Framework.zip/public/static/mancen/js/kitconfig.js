layui.define(function(exports) {

    var kitconfig = {
        resourcePath: 'static/mancen/', //框架资源路径-相对路径和绝对路径
    };

    exports('kitconfig', kitconfig);
});