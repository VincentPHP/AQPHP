<?php
namespace home\controller;

use common\controller\HomeBase;

class Index extends HomeBase{
    
    public function index()
    {
        $this->display();
    }
}