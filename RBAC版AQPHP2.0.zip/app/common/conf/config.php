<?php
/* +----------------------------------------------------------------
 * | Software: [AQPHP framework]
 * |  WebSite: www.aqphp.com
 * |----------------------------------------------------------------
 * | Author: 赵 港 <Vincent> < admin@gzibm.com | 847623251@qq.com >
 * | WeChat: GZIDCW
 * | Copyright (C) 2015-2020, www.aqphp.com All Rights Reserved.
 * +----------------------------------------------------------------*/

return array(
    //数据库配置
    "DBHOST"    => 'localhost',   //数据库地址
    "DBNAME"    => 'vlcms',       //数据库库名
    "DBUSER"    => 'root',        //用户名
    "DBPWD"     => '',            //密 码
    "DBFIX"     => 'vl_',         //表前缀
);